# katsura-agent

기본 `nodeSelector: []`는 DaemonSet에서 `nodeSelector`를 생략한다. 별도 라벨 없이 배치 가능한 노드마다 Pod 하나를 실행한다. 워커 전용 설정은 아니며, taint가 있는 노드는 필요할 때 해당 `tolerations`만 추가한다. 혼합 클러스터에서는 Linux 이미지의 OS와 빌드 아키텍처에 맞는 노드만 선택한다. 예를 들어 amd64 빌드라면 다음 override를 사용한다.

```yaml
nodeSelector:
  kubernetes.io/os: linux
  kubernetes.io/arch: amd64
```

`hostNetwork: true`는 노드 NIC에서 receive-only LLDP를 수집한다. `false`면 Pod의 네트워크에서만 조회하므로 물리 NIC의 이웃을 기대하면 안 된다. `dnsPolicy`를 비워 두면 hostNetwork에 따라 자동 선택한다. `interfaceName`을 비우면 `en*`를 탐색하고 `eth0` 같은 정확한 이름을 주면 daemon과 수집기가 같은 NIC를 사용한다. socket/chroot 경로와 receive-only 모드는 이미지 계약으로 유지한다.

배치·네트워크·보안 컨텍스트·컨테이너별 리소스 등 설정은 `values.yaml`에 있다. `resources`는 공통 기본값이고 `lldpd.resources` 또는 `collector.resources`를 지정하면 해당 컨테이너만 교체한다. 공유 소켓의 그룹 권한과 daemon 권한을 변경할 때는 이미지와의 호환성을 확인한다. 같은 노드에 기존 lldpd나 다른 릴리스를 중복 배치하지 않는다.

## 게시자: 저장소 루트에서 GHCR로 릴리스

아래는 실제 게시를 원할 때만 실행한다. 실행 이미지와 차트는 별도 패키지다.

```sh
docker login ghcr.io -u BellTigerLee
IMAGE=ghcr.io/belltigerlee/katsura-agent:lldp-1.0.23
IMAGE="$IMAGE" ./hack/build-image.sh
docker push "$IMAGE"

helm registry login ghcr.io -u BellTigerLee
helm lint charts/katsura-agent --strict
helm package charts/katsura-agent -d dist
helm push dist/katsura-agent-0.1.0.tgz oci://ghcr.io/belltigerlee/charts
```

## 사용자: 게시된 차트를 원격에서 설치

```sh
CHART=oci://ghcr.io/belltigerlee/charts/katsura-agent
helm pull "$CHART" --version 0.1.0  # 다운로드만 할 때; 설치 전 필수 아님
helm upgrade --install katsura-agent "$CHART" --version 0.1.0 \
  --namespace katsura-system --create-namespace
kubectl -n katsura-system get daemonset katsura-agent
```

`DESIRED`가 0이면 노드 라벨과 taint/toleration을 확인한다. 실행 설정은 `helm show values "$CHART" --version 0.1.0`으로 보고 `-f my-values.yaml`로 변경한다. 차트가 비공개면 Helm 클라이언트에서 GHCR에 로그인하고, 이미지가 비공개면 대상 네임스페이스에 있는 registry Secret을 `imagePullSecrets: [{name: ghcr-pull}]`로 지정한다.
